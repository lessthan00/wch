/*Assembler of on line Programmable Flash EEPROM
It is suitable to the expansion card CH361/CH362/CH365.
The program supports directly Flash chip.
The following Flash chip can use it without any change:
Size=128KB,Sector=128B:
Atmel company AT29C010A, SST company PH29EE010, Winband company W29C011 and so on.
If change 128 Bytes into 16K Bytes per Sector, it supports the following chip:
Size=128KB, Sector=16 KB: AMD company AM29F010B, SI company M29F010B and so on.
The erase time of the above chips will be different.
You can consult to the relative technology data.
SYS_EX pin of CH365 is used as A16 address line of 128K 010 flash chip.
The program is selected  from the watching program of  CH362/CH365 expension card.
**************************************
NanJing  Qingheng  Electronics CO,LTD
web site:http://winchiphead.com
support: tech@winchiphead.com
**************************************
2005.11*/
#include	<dos.h>
#include    <stdio.h>
#include	<stddef.h>
#include	"CH365DOS.C"  /* from CH365EVT.ZIP */
VOID  Ch36delayus(ULONG  a)
{
	while ( a -- )
	{  /* Every circle is  about 1uS */
			inportb( (USHORT) & dosIoBaseAddr -> mCh365IoPort[0] );  /* Read the hardware counter. */
			inportb( (USHORT) & dosIoBaseAddr -> mCh365IoPort[0] );
			inportb( (USHORT) & dosIoBaseAddr -> mCh365IoPort[0] );

	}
}
USHORT Ch36CheckDevice( )  /* Check the CH365 device,and return the PCI Address of CH365 which is bus/device/function number.If it has error,return 0*/
{
	USHORT	i,l;
	for(dosCH365PciAddr=0;dosCH365PciAddr<=0x800;dosCH365PciAddr=dosCH365PciAddr+8)
	{
		if (((CH365ReadCfgWord(0x0006))&0xff00)==0x0400)/*Read the configuration space offset0x06h*/  
		{
			i=CH365ReadCfgWord(0x0040);/*Read the configuration space offset 0x40h that is name of CH365*/
			l=CH365ReadCfgWord(0x0044);/*Read the configuration space offset 0x44h that is alias of CH365*/
			if (i==l)
				return(dosCH365PciAddr);
		}
		
	}
	
	return(0);
}


void Selblock(UCHAR  i )  /*Select the 64k data block of ROM*/
{   
	
	outportb((USHORT) & dosIoBaseAddr->mCh365IoCtrl, ( i? mBitSysExtOut : 0 ) );
}


UCHAR Get128B(ULONG p,UCHAR buffer[256],FILE *filep)/*Get the source data*/
{   
	USHORT   i=0;
	fseek(filep,p,0);
	if ((fread(&buffer[i],1,128,filep))!=128)
		return(FALSE);
	else
		return(TRUE);
	
}

UCHAR  Read_Rom_1B  ( ULONG  addr)/* Read 1 Byte  data from Rom*/
{ 
	outport((USHORT) & dosIoBaseAddr->mCh365MemAddrL,addr);/*Write the Rom address to I/O port*/
	return( inportb((USHORT) & dosIoBaseAddr->mCh365MemData) );/*Read the Rom data from I/O port*/
}

ULONG  Write_Rom_1B  (ULONG addr,UCHAR dat)/* Write 1 byte data to ROM*/
{
	outport((USHORT) & dosIoBaseAddr->mCh365MemAddrL,addr);/*Write the Rom address to I/O port*/
	outportb((USHORT) & dosIoBaseAddr->mCh365MemData,dat);/*Write the Rom data to Rom*/
}

VOID  Read_ROM_128B(ULONG saddr,PUCHAR sbuffer)/*Read 128 bytes to Rom*/
{
	USHORT i;
	outport((USHORT) & dosIoBaseAddr->mCh365MemAddrL,saddr);/*Write the Rom address to I/O port*/
	for(i=0;i<128;i++)
	{
		*sbuffer=inportb((USHORT) & dosIoBaseAddr->mCh365MemData);/*Read the Rom data from Rom*/
		sbuffer++;
	}
}
void Write_Rom_128B(ULONG Saddr, PUCHAR Sbuffer)/* Write 128 Bytes to rom*/
{
	USHORT  i;
	outport((USHORT) & dosIoBaseAddr->mCh365MemAddrL,Saddr);/*Write the Rom address to I/O port*/
	for(i=0;i<128;i++)
	{
		outportb((USHORT) & dosIoBaseAddr->mCh365MemData,*Sbuffer);/*Write the Rom data to I/O port*/
		Sbuffer++;
	}
}

UCHAR Program_128B(ULONG addr,PUCHAR SrcBuf)/*Program 128  Bytes*/
{
	USHORT  i,retry;
	PUCHAR   buffer;/* The ROM data buffer*/
	buffer=SrcBuf+128;
	for(retry=3;retry!=0;retry--)/* The rewrite frequency of writting data in Program_128B */
	{          	
		Selblock(0);
       
		Write_Rom_1B(0x5555,0xaa);/*Write the SDP signature into the flash*/
		Write_Rom_1B(0x2aaa,0x55);/*Write the SDP signature into the flash*/			
		Write_Rom_1B(0x5555,0xa0);/*Write the SDP signature into the flash*/
		Selblock( (addr>0x10000) ? 1 : 0);/*Select the block*/
		Write_Rom_128B(addr,SrcBuf);/*Write the code 128B*/
		Ch36delayus(20000);  /* Delay 20ms*/
		
		Read_ROM_128B(addr,buffer);/*Reread the code 128B*/
	    
		for(i=0;i<128;i++) /*Compare the data between the file data and Rom data*/ 
		{	
			
			if (*buffer++!=*SrcBuf++)
					break;
			
		}
		if (i>=128)	/* If it is right, return the main function*/
			return(TRUE);
	}
	return(FALSE);
}


UCHAR Verify_128B(ULONG addr,PUCHAR  SrcBuf)/* Verify the data again*/
{
	USHORT  i;						
	UCHAR   buffer[256];/* The ROM data buffer*/
	Read_ROM_128B(addr,buffer);/*Read 128 Bytes to bufferb*/
	for(i=0;i<128;i++)
	{	
		if (buffer[i]!=*SrcBuf++)
			
			return(FALSE);
		
	}
	return (TRUE);
}

ULONG Getlen(UCHAR Filenam[10])/*Get the file length*/
{	FILE   *Sfp;
	ULONG  i;	
	
	if((Sfp=fopen(Filenam,"rb"))==NULL)/*Open the file*/
	{	
		printf("Can't open file for getting length.");
		fclose(Sfp);/*Close the file*/
		exit(0);
	}
	else 
	{
		fseek(Sfp,0L,2);/*File pointer points to the NULL*/
		
		if(ftell(Sfp)!=-1L)
		{
			i=ftell(Sfp);
			fclose(Sfp);
			return(i);
		}
		else 
		{
			fclose(Sfp);
			printf("EEROR");
			exit(0);
		}
		
	}
}


VOID main()
{  
	UCHAR                 Filename[10];/*The file name to write*/ 
	ULONG                 RomStartAddr;/*The  start address of  Rom.*/
	ULONG                 RomFileLen;/*The length of ROM file*/
	UCHAR                 buffer1[256];/*The source data buffer*/
	FILE                  *fp;/* The source data pointer*/
	
	printf("***Check  device***\n");
	if ((dosCH365PciAddr=Ch36CheckDevice( ))!=0)             /*Check the CH365 device*/
	{
		dosIoBaseAddr=CH365GetIoBaseAddr( );/*Get the I/O base address*/
		printf("dosIoBaseAddr=%x\n",dosIoBaseAddr);
		printf("Please input the file name:");
		scanf("%s",Filename);
		RomFileLen=Getlen(Filename);
		if((fp=fopen(Filename,"rb"))==NULL)/*Open the file*/
		{	
			printf("Can't open file .");
			fclose(fp);/*Close the file*/
			exit(0);
		}
		else
		{
			printf("***Start to write  code***\n");
			
			for(RomStartAddr=0;RomStartAddr<RomFileLen;RomStartAddr=RomStartAddr+128)                  /*Write the 128 Bytes to ROM */
			{   
				if(Get128B(RomStartAddr,buffer1,fp)==TRUE)  
					
				{
					printf(".");
					if (Program_128B(RomStartAddr,buffer1)!=TRUE)
						
					{   
						printf("\n***Writting code is wrong***\n");
							
							return;
						
					}
				}
				else 
				{
					printf("\n***Getting data has error***\n");
					fclose(fp);
					return;
				}
				Ch36delayus(10000);/*It is optional*/
			}
			
			for(RomStartAddr=0;RomStartAddr<RomFileLen;RomStartAddr=RomStartAddr+128)           /*Verify the 128 bytes */
			{     
				if(Get128B(RomStartAddr,buffer1,fp)==TRUE)/*Get the source data again.*/
				{
					if (Verify_128B(RomStartAddr,buffer1)!=TRUE)
						
					{
						printf("\n***Verification of the data has error***\n");/*If it has error,print the message.*/
						fclose(fp);/*Close file*/
						return;
					}
				}
			}
		}
		printf("\n***Writting data is finished***\n");
		fclose(fp);/*Close file*/
		return;
	}	



printf("\n***Find no device****\n");
return;

}
