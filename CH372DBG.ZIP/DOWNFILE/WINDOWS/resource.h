//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DEMO.RC
//
#define VER_DEBUG                       0
#define VER_PRERELEASE                  0
#define VER_PRODUCTBUILD_QFE            12
#define VER_PRODUCTVERSION_W            0x010A
#define VER_PRODUCTBUILD                2004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
