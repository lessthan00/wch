// 2011.07.18
//****************************************
//**  Copyright  (C)  W.ch  2010-2011   **
//**  Web:  http://www.winchiphead.com  **
//****************************************
//**  EXE for PCIE interface chip CH367 **
//**  C, VC6.0                          **
//****************************************
//
// PCI���߽ӿ�оƬCH367��Ӧ�ò���ʾ���� V1.0
// �Ͼ��ߺ�������޹�˾  ����: W.ch 2011.07
// ���л���: Windows 98/ME, Windows 2000/XP
//

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <iostream.h>
#include <string.h>

#include "resource.h"
#include "CH367DLL.H"
#include "DEBUG367.H"

#include "SUB.C"

/* ������� */
int	APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nShowCmd)
{
	mSaveInstance = hInstance;
	return(DialogBox(hInstance, (LPCTSTR)IDD_MAIN, NULL, mDialogMain)); /* �������Ի��� */
}

/* ���Ի����¼� */
LRESULT CALLBACK mDialogMain(HWND hDialog, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	switch(uMessage)
	{
	case WM_INTNOTIFY:
		{
			sprintf(irq_buf, "%d", mCount);
			SetWindowText(GetDlgItem(hDialog, IDC_EDIT_IRQ), irq_buf);
		}
		return TRUE;
	case WM_INITDIALOG:
		{
			mSaveDialogMain = hDialog;
			mInitCheckBox(hDialog);
			if(LoadLibrary("CH367DLL.DLL") == NULL) /* ��Ҫʹ��DLL����Ҫ�ȼ��� */
			{
				MessageBox(hDialog, "�޷�����CH367��DLL", mCaptionInform, MB_ICONSTOP | MB_OK); /* ����DLLʧ��,����δ��װ��ϵͳ�� */
				EndDialog(hDialog, 0x81); /* �رնԻ��� */
				return TRUE;
			}
			SetDlgItemText(hDialog, IDC_STATUS, "�豸�ر�,���ȴ�ָ���豸");
		}
		return TRUE;
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case IDC_BTNIO: /* I/O�ռ��д */
				{
					if(flag_open)
					{
						mIOReadWrite(hDialog);
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_BTNCONBYTE: /* ���ÿռ��д */
				{
					if(flag_open)
					{
						mConReadWrite(hDialog);
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_BTNI2C: /* ��I2C�ӿڲ��� */
				{
					if(flag_open)
					{
						mSetI2C(hDialog);
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_BTNI2C_PROGRAM: /* ������д */
				{
					if(flag_open)
					{
						DialogBox(mSaveInstance, (LPCTSTR)IDD_I2C_PROGRAM, NULL, mDialogI2c);
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_SPI: /* ����SPI�ӿ�FLASH */
				{
					unsigned char buffer[4];
					if(flag_open)
					{
						read_manufacturer_device_id(buffer);
						if(buffer[0] == 0xBF && buffer[1] == 0x48 && buffer[2] == 0xBF && buffer[3] == 0x48)
						{
							DialogBox(mSaveInstance, (LPCTSTR)IDD_SPI_PROGRAM, NULL, mDialogSpi);
						}
						else
						{
							MessageBox(hDialog, "FLASH�Ѿ���,����û������", mCaptionInform, MB_OK);	
						}
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_SPI_SET: /* SPI���� */
				{	
					ULONG mode;
					if(IsDlgButtonChecked(hDialog, IDC_SPI_31) == BST_CHECKED)
					{
						if(IsDlgButtonChecked(hDialog, IDC_SPI3) == BST_CHECKED)
						{
							mode = 0;
						}
						else
						{
							mode = 0x02;
						}
					}
					else
					{
						if(IsDlgButtonChecked(hDialog, IDC_SPI3) == BST_CHECKED)
						{
							mode = 0x01;
						}
						else
						{
							mode = 0x03;
						}	
					}
					if(flag_open)
					{
						CH367SetStream(mIndex, mode);
						MessageBox(hDialog, "����SPI�ɹ�", mCaptionInform, MB_OK);
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}	
				}
				return TRUE;
			case IDC_IRQ_TEST: /* �����ж� */
				{
					int count = 10;
					if(flag_open)
					{
						MessageBox(hDialog, "��ȷ��INT#��A15����,���򽫲�������ж�", mCaptionInform, MB_OK);
						CH367_GPO_SET;
						CH367_GPO_CLR;
					}
					else
					{
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_CLOSE: /* �ر��豸 */
				{
					if(flag_open)
					{
						flag_open = 0x00;
						CH367mCloseDevice(mIndex);
						sprintf(buffer_close, "�豸%d�Ѿ��ر�", mIndex);
						SetDlgItemText(hDialog, IDC_STATUS, buffer_close);
						EnableWindow(GetDlgItem(hDialog, IDC_BTNIO), FALSE); /* �������ɼ� */
						EnableWindow(GetDlgItem(hDialog, IDC_BTNCONBYTE), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_IRQ_TEST), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_BTNI2C), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_BTNI2C_PROGRAM), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_SPI_SET), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_SPI), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_CLOSE), FALSE);
						EnableWindow(GetDlgItem(hDialog, IDC_OPEN), TRUE); /* ���豸�����ɼ�*/
						EndDialog(mSaveDialogSpi, 1); /* �ر�SPI�Ի��� */
						EndDialog(mSaveDialogI2c, 1); /* �ر�I2C�Ի��� */
					}
					else
					{
						sprintf(buffer_close, "�豸%dû�д�", mIndex);
						MessageBox(hDialog, buffer_close, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_OPEN: /* ���豸 */
				{
					if(!flag_open)
					{
						mIndex = (UCHAR)SendDlgItemMessage(hDialog, IDC_DEVICE_NUMBER, CB_GETCURSEL, 0, 0); /* ���Ҫ�򿪵��豸�� */
						if(CH367mOpenDevice(mIndex, FALSE, TRUE, 0x00) == INVALID_HANDLE_VALUE) /* ��ֹMEM, ʹ���ж�, ��ƽ�ж�ģʽ, �͵�ƽ���� */
						{
							sprintf(buffer_open, "�޷����豸%d,��ȷ���豸�Ѿ�����", mIndex);
							MessageBox(hDialog, buffer_open, mCaptionInform, MB_ICONSTOP | MB_OK);
							return( TRUE );
						}
						else
						{
							flag_open = 0x01;
							mShowDllVer(hDialog); /* ��ʾDLL�汾�� */
							mShowDevVer(hDialog); /* ��ʾ�����汾�� */
							AddrRefresh(hDialog);
							CH367mSetIntRoutine(mIndex, InterruptEvent); /* �����жϷ������ */
							sprintf(buffer_open, "�豸%d�Ѿ���", mIndex);
							SetDlgItemText(hDialog, IDC_STATUS, buffer_open);
							EnableWindow(GetDlgItem(hDialog, IDC_BTNIO), TRUE); /* �����ɼ� */
							EnableWindow(GetDlgItem(hDialog, IDC_BTNCONBYTE), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_IRQ_TEST), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_BTNI2C), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_BTNI2C_PROGRAM), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_SPI_SET), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_SPI), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_CLOSE), TRUE);
							EnableWindow(GetDlgItem(hDialog, IDC_OPEN), FALSE); /* ���豸�������ɼ�*/
						}
					}
					else
					{
						MessageBox(hDialog, buffer_open, mCaptionInform, MB_OK);
					}
				}
				return TRUE;
			case IDC_DESCRIPTION: /* ����˵�� */
				{
					DialogBox(mSaveInstance, (LPCTSTR)IDD_HELP, NULL, mDialogHelp);
				}
				return TRUE;
			case IDC_EXIT:
			case WM_DESTROY: /* �˳� */
				CH367mCloseDevice(mIndex);
				EndDialog(hDialog, 1);
				return TRUE;
			}
		}
		break;
	}
	return FALSE;  
}

