//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DEBUG367.RC
//
#define IDD_MAIN                        101
#define IDI_ICON                        102
#define IDD_I2C_PROGRAM                 103
#define IDD_SPI_PROGRAM                 104
#define IDD_HELP                        105
#define IDC_EDTIOADDR                   1000
#define IDC_EDTIODATA                   1001
#define IDC_RADOFF                      1002
#define IDC_RADIME                      1003
#define IDC_RADIOWRITE                  1004
#define IDC_RADIOREAD                   1005
#define IDC_RADIOBYTE                   1006
#define IDC_RADIOWORD                   1007
#define IDC_RADIODWORD                  1008
#define IDC_EDTDLLVER                   1009
#define IDC_EDTDEVVER                   1010
#define IDC_OPEN                        1011
#define IDC_CLOSE                       1012
#define IDC_DESCRIPTION                 1013
#define IDC_BTNIO                       1014
#define IDC_BTNCONBYTE                  1015
#define IDC_RADCONBYTEWRITE             1016
#define IDC_RADCONBYTEREAD              1017
#define IDC_EDTCONBYTEADDR              1018
#define IDC_EDTCONBYTEDATA              1019
#define IDC_EXIT                        1021
#define IDC_EDTINTLINE                  1022
#define IDC_EDTBASEADDR                 1023
#define IDC_EDTMEM                      1024
#define IDC_BTNMEM                      1025
#define IDC_EDTMEMADDR                  1026
#define IDC_RADMEMBYTE                  1027
#define IDC_RADMEMDWORD                 1028
#define IDC_RADMEMREAD                  1029
#define IDC_RADMEMWRITE                 1030
#define IDC_EDTMEMDATA                  1031
#define IDC_STATUS                      1035
#define IDC_RADI2CREAD                  1036
#define IDC_RADI2CWRITE                 1037
#define IDC_EDTDEVADDR                  1038
#define IDC_EDTDATADDR                  1039
#define IDC_BTNI2C                      1040
#define IDC_EDTI2CDATA                  1041
#define IDC_BTNI2C_PROGRAM              1042
#define IDC_VID                         1048
#define IDC_DID                         1049
#define IDC_RID                         1050
#define IDC_SVID                        1051
#define IDC_SID                         1052
#define IDC_PROGRAM                     1053
#define IDC_PROGRAM_EXIT                1054
#define IDC_SPI                         1055
#define IDC_SPI_31                      1056
#define IDC_SPI_15                      1057
#define IDC_SPI3                        1058
#define IDC_SPI4                        1059
#define IDC_SPI_SET                     1060
#define IDC_FLASH_WRITE                 1061
#define IDC_FLASH_ERASE                 1062
#define IDC_FLASH_EXIT                  1063
#define IDC_FLASH_READ                  1064
#define IDC_FLASH_LOADFILE              1065
#define IDC_FILE                        1066
#define IDC_COMBO_IRQ_TYPE              1068
#define IDC_COMBO_IRQ_POLARITY          1069
#define IDC_IRQ_SET                     1070
#define IDC_IRQ_TEST                    1071
#define IDC_EDIT_IRQ                    1072
#define IDC_DEVICE_NUMBER               1074
#define IDC_EDIT_HELP                   1075

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1080
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
